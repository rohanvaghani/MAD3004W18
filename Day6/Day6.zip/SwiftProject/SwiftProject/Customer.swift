//
//  Customer.swift
//  Day6
//
//  Created by Kuljeet Singh on 2018-02-05.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import Foundation

class Customer : User {
    //customerID is gonna be the link between Shopping Cart entity, Orders entity with Customer entity
    //every customer has userID, but not the reverse
    var customerID: String?
    var customerName : String?
    var address : String?
    var email : String?
    var creditCardInfo : String?
    var shippingInfo : String?
    
    override init() {
        super.init()
        self.customerID = ""
        self.customerName = ""
        self.address = ""
        self.email = ""
        self.creditCardInfo = ""
        self.shippingInfo = ""
    }
    
    init(cCustomerID: String, cUserID: String,  cName: String, cAddress: String, cEmail: String, cCreditInfo: String, cShippingInfo: String) {
        super.init(userID: cUserID)
        self.customerID = cCustomerID
        self.customerName = cName
        self.address = cAddress
        self.email = cEmail
        self.creditCardInfo = cCreditInfo
        self.shippingInfo = cShippingInfo
    }
    
    init(customerID: String){
        self.customerID = customerID
    }
    
    func register() {
        
    }
    
    func login() {
        
    }
    
    func updateProfile() {
        
    }
    
    
}
