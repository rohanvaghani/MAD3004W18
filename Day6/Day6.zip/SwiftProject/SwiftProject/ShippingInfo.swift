//
//  ShippingInfo.swift
//  Day6
//
//  Created by Kuljeet Singh on 2018-02-05.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import Foundation

class ShippinngInfo {
    var shippingID: Int?
    var shippingType: String?
    var shippingCost: Int?
    var shippingRegionID: Int?
    
    init() {
        self.shippingID = 0
        self.shippingType = ""
        self.shippingCost = 0
        self.shippingRegionID = 0
    }
    
    init(sShippingID: Int, sShippingType:String, sShippingCost: Int, sShippingRegionID: Int) {
        self.shippingID = sShippingID
        self.shippingType = sShippingType
        self.shippingCost = sShippingCost
        self.shippingRegionID = sShippingRegionID
    }
    
    func updateShippingInfo() {
        
    }
}
