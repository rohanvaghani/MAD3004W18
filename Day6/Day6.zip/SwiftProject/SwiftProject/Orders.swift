//
//  Orders.swift
//  Day6
//
//  Created by Kuljeet Singh on 2018-02-05.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import Foundation

class Orders: Customer {
   
    var orderID: Int?
    var dateCreated: String?
    var dateShipped: String?

    var status: String?
    var shippingID: String?
    
    override init() {
        self.orderID = 0
        self.dateCreated = ""
        self.dateShipped = ""
        self.status = ""
        self.shippingID = ""
        super.init()
    }
    
    init(oOrderID:Int,oDateCreated:String,oDateShipped:String, oStatus: String, oShippingID: String) {
        self.orderID = oOrderID
        self.dateCreated = oDateCreated
        self.dateShipped = oDateShipped

        self.status = oStatus
        self.shippingID = oShippingID
        
        super.init(cCustomerID: "7")
    }
    
    func placeOrder() {
        
    }
}
