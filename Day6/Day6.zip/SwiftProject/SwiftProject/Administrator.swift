//
//  Administrator.swift
//  Day6
//
//  Created by Kuljeet Singh on 2018-02-05.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import Foundation

class Administrator: User {
    
    var adminName : String?
    var email : String?
 
    
    override init() {
        super.init()
        
        self.adminName = ""
        self.email = ""

    }
    
    func updateCatalog() -> Bool {
        return true
    }
    
    init(cUserID: String, aName: String,aEmail: String) {
        super.init(userID: cUserID)
        self.adminName = aName
        self.email = aEmail
    }
}
